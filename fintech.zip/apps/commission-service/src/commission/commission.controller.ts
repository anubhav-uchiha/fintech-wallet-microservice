import { Controller } from '@nestjs/common';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { CommissionService } from './commission.service';
import { CreateCommissionDto } from './dto/create-commission.dto';
import { CalculateCommissionDto } from './dto/calculate-commission.dto';

@Controller()
export class CommissionController {
  constructor(private readonly commissionService: CommissionService) {}

  @MessagePattern({ cmd: 'create_commission' })
  create(@Payload() dto: CreateCommissionDto) {
    return this.commissionService.create(dto);
  }

  @MessagePattern({ cmd: 'get_all_commission' })
  getAll() {
    return this.commissionService.getAll();
  }

  @MessagePattern({ cmd: 'calculate_commission' })
  calculate(@Payload() dto: CalculateCommissionDto) {
    return this.commissionService.calculate(dto.serviceType, dto.amount);
  }
}
