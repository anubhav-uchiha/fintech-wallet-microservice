import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

import { Commission } from './commission.schema';
import { CreateCommissionDto } from './dto/create-commission.dto';
import { RedisService } from '../redis/redis.service';

@Injectable()
export class CommissionService {
  constructor(
    @InjectModel(Commission.name)
    private readonly commissionModel: Model<Commission>,

    private readonly redisService: RedisService,
  ) {}

  async create(dto: CreateCommissionDto) {
    return this.commissionModel.create(dto);
  }

  async getAll() {
    return this.commissionModel.find();
  }

  async calculate(serviceType: string, amount: number) {
    const cacheKey = `commission:${serviceType}`;

    const cached = await this.redisService.get(cacheKey);

    if (cached) {
      console.log('✅ Commission loaded from Redis');

      const rule = JSON.parse(cached);

      const commission =
        rule.commissionType === 'PERCENTAGE'
          ? (amount * rule.value) / 100
          : rule.value;

      return {
        commission,
        totalDebit: amount + commission,
      };
    }

    console.log('⚡ Commission loaded from MongoDB');

    const rule = await this.commissionModel.findOne({
      serviceType,
      isActive: true,
    });

    if (!rule) {
      throw new Error('Commission not configured');
    }

    await this.redisService.set(cacheKey, rule);

    const commission =
      rule.commissionType === 'PERCENTAGE'
        ? (amount * rule.value) / 100
        : rule.value;

    return {
      commission,
      totalDebit: amount + commission,
    };
  }
}
